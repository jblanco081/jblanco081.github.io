///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"
#include "ShaderManager.h"
#define GLM_ENABLE_EXPERIMENTAL  
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>  
#include <glm/gtc/type_ptr.hpp>

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/



/***********************************************************
* LoadSceneTextures()
*
* This method is used for preparing the 3D scene by loading
* the shapes, textures in memory to support the 3D scene
* rendering
***********************************************************/
void SceneManager::LoadSceneTextures()
{
	bool bReturn = false;

	bReturn = CreateGLTexture("../../Utilities/textures/monitor.jpg","monitor");
	bReturn = CreateGLTexture("../../Utilities/textures/screen.jpg","screen");
	bReturn = CreateGLTexture("../../Utilities/textures/rusticwood.jpg", "wood"); 
	bReturn = CreateGLTexture("../../Utilities/textures/drywall.jpg", "drywall");
	

	// after the texture image data is loaded into memory, the
// loaded textures need to be bound to texture slots - there
// are a total of 16 available slots for scene textures

	BindGLTextures();
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	LoadSceneTextures();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();

	DefineObjectMaterials();
	SetupSceneLights();
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is called to add and configure the light
 *  sources for the 3D scene.  There are up to 4 light sources.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// Enable custom lighting
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// Ambient light
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.3f, 0.3f, 0.3f);
    m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.0f, 0.0f, 0.0f); // No diffuse
    m_pShaderManager->setVec3Value("lightSources[0].specularColor", 0.0f, 0.0f, 0.0f); // No specular
    m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 1.0f);
    m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.0f);

    // Diffuse light coming from the window (simulate sunlight)
    m_pShaderManager->setVec3Value("lightSources[1].position", 0.0f, 15.0f, 6.0f); // Higher position outside the window
    m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.1f, 0.1f, 0.1f);
    m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.5f, 0.5f, 0.5f);
    m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.0f, 0.0f, 0.0f); // No specular
    m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 32.0f);
    m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.0f);

    // Specular light for the monitor and lamp
    m_pShaderManager->setVec3Value("lightSources[2].position", 0.0f, 5.0f, 5.0f); // Position near the monitor and lamp
    m_pShaderManager->setVec3Value("lightSources[2].ambientColor", 0.1f, 0.1f, 0.1f);
    m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", 0.4f, 0.4f, 0.4f);
    m_pShaderManager->setVec3Value("lightSources[2].specularColor", 0.0f, 0.0f, 1.0f); // Purple tint for specular highlights
    m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 500.0f);
    m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 1.0f);

    // Additional light source to ensure the entire scene is lit
    m_pShaderManager->setVec3Value("lightSources[3].position", 0.0f, 15.0f, -10.0f); // Higher position to cover shadowed areas
    m_pShaderManager->setVec3Value("lightSources[3].ambientColor", 0.1f, 0.1f, 0.1f);
    m_pShaderManager->setVec3Value("lightSources[3].diffuseColor", 0.3f, 0.3f, 0.3f);
    m_pShaderManager->setVec3Value("lightSources[3].specularColor", 0.0f, 0.0f, 0.0f); // No specular
    m_pShaderManager->setFloatValue("lightSources[3].focalStrength", 32.0f);
    m_pShaderManager->setFloatValue("lightSources[3].specularIntensity", 0.0f);

}

void SceneManager::DefineObjectMaterials()
{
	OBJECT_MATERIAL monitorMaterial;
	monitorMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	monitorMaterial.ambientStrength = 0.1f;
	monitorMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
	monitorMaterial.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
	monitorMaterial.shininess = 32.0f;
	monitorMaterial.tag = "monitor";
	m_objectMaterials.push_back(monitorMaterial);

	OBJECT_MATERIAL screenMaterial;
	screenMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	screenMaterial.ambientStrength = 0.1f;
	screenMaterial.diffuseColor = glm::vec3(0.7f, 0.7f, 0.7f);
	screenMaterial.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
	screenMaterial.shininess = 32.0f;
	screenMaterial.tag = "screen";
	m_objectMaterials.push_back(screenMaterial);
}



/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// Set the background color to light gray
	glClearColor(0.9f, 0.9f, 0.9f, 1.0f); // RGBA values for light gray
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, -1.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/

	//roof
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);
	positionXYZ = glm::vec3(0.0f, 10.5f, -1.0f); // Position it behind the desk
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("drywall"); // Light gray color for the wall, or use SetShaderTexture if you want to apply a texture
	m_basicMeshes->DrawPlaneMesh();

	//backwall
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);
	positionXYZ = glm::vec3(0.0f, 8.5f, -2.0f); // Position it behind the desk
	SetTransformations(scaleXYZ, 90.0f, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("drywall"); // Light gray color for the wall, or use SetShaderTexture if you want to apply a texture
	m_basicMeshes->DrawPlaneMesh();

	//the monitor screen
	scaleXYZ = glm::vec3(5.0f, 3.0f, 0.1f); // Scale for the screen
	positionXYZ = glm::vec3(0.0f, 4.5f, -1.0f); // Position for the screen
	SetTransformations(scaleXYZ, XrotationDegrees, -15.0f, ZrotationDegrees, positionXYZ);
	//SetShaderColor(0.0f, 0.0f, 0.0f, 1.0f); // Black color for the screen
	SetShaderTexture("monitor");
	m_basicMeshes->DrawBoxMesh();

	//the monitor display
	scaleXYZ = glm::vec3(4.7f, 2.7f, 0.0f); // Scale for the screen
	positionXYZ = glm::vec3(0.0f, 4.5f, -0.9f); // Position for the screen
	SetTransformations(scaleXYZ, XrotationDegrees, -15.0f, ZrotationDegrees, positionXYZ);
	//SetShaderColor(0.3f, 0.3f, 0.7f, 1.0f); // Blue-purple color for the screen
	SetShaderTexture("screen");
	SetShaderMaterial("screen");
	m_basicMeshes->DrawBoxMesh();

	//the monitor stand (Cylinder)
	scaleXYZ = glm::vec3(0.2f, 2.5f, 0.2f); // Scale for the stand
	positionXYZ = glm::vec3(0.0f, 1.5f, -1.2f); // Position for the stand
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	//SetShaderColor(0.5f, 0.5f, 0.5f, 1.0f); // Gray color for the stand
	SetShaderTexture("monitor");
	m_basicMeshes->DrawCylinderMesh();

	//the base of the stand
	scaleXYZ = glm::vec3(1.5f, 0.1f, 1.0f); // Scale for the base
	positionXYZ = glm::vec3(0.0f, 1.8f, -1.1f); // Position for the base
	SetTransformations(scaleXYZ, XrotationDegrees, -10.0f, ZrotationDegrees, positionXYZ);
	//SetShaderColor(0.5f, 0.5f, 0.5f, 1.0f); // Gray color for the base
	SetShaderTexture("monitor");
	m_basicMeshes->DrawBoxMesh();

	// Desk
	scaleXYZ = glm::vec3(10.0f, 0.5f, 5.0f);
	positionXYZ = glm::vec3(0.0f, 1.5f, 0.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("wood");
	m_basicMeshes->DrawBoxMesh();

	// Chair seat
	scaleXYZ = glm::vec3(2.0f, 0.5f, 2.0f);
	positionXYZ = glm::vec3(0.0f, 0.8f, 4.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// Chair backrest
	scaleXYZ = glm::vec3(2.0f, 3.0f, 0.5f);
	positionXYZ = glm::vec3(0.0f, 2.0f, 5.25f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	//keyboard
	scaleXYZ = glm::vec3(4.0f, 0.1f, 1.5f); // Scale to match a typical keyboard size
	positionXYZ = glm::vec3(0.0f, 1.8f, 0.8f); // Position on the desk
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(0.2f, 0.2f, 0.2f, 1.0f); // Dark gray for the keyboard base
	m_basicMeshes->DrawBoxMesh(); // Draw the keyboard base

	// Keys on the keyboard
	scaleXYZ = glm::vec3(0.3f, 0.1f, 0.3f); // Scale for the keys
	for (int i = 0; i < 10; i++) {
		positionXYZ = glm::vec3(-1.8f + i * 0.4f, 1.9f, 0.8f); // Adjust position for each key
		SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
		SetShaderColor(0.3f, 0.3f, 0.3f, 1.0f); // Lighter gray for the keys
		m_basicMeshes->DrawBoxMesh(); // Draw each key
	}

	// Mouse 
	scaleXYZ = glm::vec3(0.35f, 0.05f, 0.45f); // Scale for the mouse buttons
	positionXYZ = glm::vec3(3.3f, 1.8f, 0.8f); // Position on the mouse
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(0.2f, 0.2f, 0.2f, 1.0f); // Darker gray for the buttons
	m_basicMeshes->DrawBoxMesh(); // Draw the mouse buttons

	// Plant Pot
	scaleXYZ = glm::vec3(0.5f, 0.5f, 0.5f); // Scale to create a small pot
	positionXYZ = glm::vec3(3.6f, 1.8f, -0.7f); // Position on the desk or floor
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(0.6f, 0.3f, 0.1f, 1.0f); // Brown color for the pot
	m_basicMeshes->DrawCylinderMesh();

	// Lamp Base
	scaleXYZ = glm::vec3(0.5f, 0.5f, 0.5f); // Scale to create a flat base
	positionXYZ = glm::vec3(-3.3f, 1.8f, -0.7f); // Position on the desk
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(0.3f, 0.3f, 0.3f, 1.0f); // Dark gray color for the base
	m_basicMeshes->DrawCylinderMesh();

	// Desk Leg 1
	scaleXYZ = glm::vec3(0.3f, 3.0f, 0.3f); // Scale to create a tall and thin leg
	positionXYZ = glm::vec3(-4.0f, 0.0f, -1.9f); // Position at the front-left corner
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(0.0f, 0.0f, 0.0f, 1.0f); // Same color as the other legs
	m_basicMeshes->DrawBoxMesh(); // Draw the first desk leg

	// Desk Leg 2
	scaleXYZ = glm::vec3(0.3f, 3.0f, 0.3f); // Same scale as the first leg
	positionXYZ = glm::vec3(4.0f, 0.0f, -1.9f); // Position at the front-right corner
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(0.0f, 0.0f, 0.0f, 1.0f); // Same color as the other legs
	m_basicMeshes->DrawBoxMesh(); // Draw the second desk leg

	// Desk Leg 3
	scaleXYZ = glm::vec3(0.3f, 3.0f, 0.3f); // Same scale as the other legs
	positionXYZ = glm::vec3(-4.0f, 0.0f, 1.9f); // Position at the back-left corner
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(0.0f, 0.0f, 0.0f, 1.0f); // Same color as the other legs
	m_basicMeshes->DrawBoxMesh(); // Draw the third desk leg

	// Desk Leg 4
	scaleXYZ = glm::vec3(0.3f, 3.0f, 0.3f); // Same scale as the other legs
	positionXYZ = glm::vec3(4.0f, 0.0f, 1.9f); // Position at the back-right corner
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(0.0f, 0.0f, 0.0f, 1.0f); // Same color as the other legs
	m_basicMeshes->DrawBoxMesh(); // Draw the fourth desk leg

	//the desktop computer tower
	scaleXYZ = glm::vec3(1.0f, 2.5f, 0.5f); // Scale for the tower
	positionXYZ = glm::vec3(2.8f, -0.6f, 1.2f); // Position for the tower on the ground
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(0.0f, 0.0f, 0.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();


}
